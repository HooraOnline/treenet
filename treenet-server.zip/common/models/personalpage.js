'use strict';

module.exports = function(Personalpage) {

};
